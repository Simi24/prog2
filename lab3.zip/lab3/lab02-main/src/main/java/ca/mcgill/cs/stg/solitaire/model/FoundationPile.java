package ca.mcgill.cs.stg.solitaire.model;

/**
 * The different foundation piles. 
 */
public enum FoundationPile implements Location
{
	FIRST, SECOND, THIRD, FOURTH
}