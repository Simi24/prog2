package ca.mcgill.cs.stg.solitaire.model;

/**
 * Represents anywhere a card can be placed in Solitaire.
 */
public interface Location 
{}