package it.unimi.di.prog2.poker;
import ca.mcgill.cs.stg.solitaire.cards.*;

public class hoCoppia implements ChainedHandEvaluator {

    private final ChainedHandEvaluator next;

    public hoCoppia(ChainedHandEvaluator nextEvaluator) {
        next = nextEvaluator;
    }

    @Override
    public PokerHand.HandRank evaluate(PokerHand pokerHand) {

        int cont = 1;

        for (Card card: pokerHand) {
            cont =1;
            for (Card card2: pokerHand) {
                if (card.getRank() == card2.getRank() && card.getSuit() != card2.getSuit()) {
                    cont++;
                }
            }
        }

        if (cont != 2) {
            return next.evaluate(pokerHand);
        }
        return PokerHand.HandRank.FLUSH;
    }
}
