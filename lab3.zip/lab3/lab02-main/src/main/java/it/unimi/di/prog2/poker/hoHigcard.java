package it.unimi.di.prog2.poker;

public class hoHigcard implements ChainedHandEvaluator {

    public hoHigcard() {
        PokerHand.HandRank result = PokerHand.HandRank.HIGH_CARD;
    }

    @Override
    public PokerHand.HandRank evaluate(PokerHand pokerHand){

        return PokerHand.HandRank.HIGH_CARD;
    }
}
