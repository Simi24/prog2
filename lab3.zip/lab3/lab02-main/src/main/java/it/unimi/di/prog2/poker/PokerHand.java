package it.unimi.di.prog2.poker;
import java.util.ArrayList;
import ca.mcgill.cs.stg.solitaire.cards.*;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class PokerHand implements Iterable<Card>, ChainedHandEvaluator, Comparable {

    List<Card> banco = new ArrayList<>();

    //per rendere itrabile la classe PokerHand creo il metodo Iterator, per farlo basta scrivere implements Iterable<Card>
    // e intelliJ lo fa in automatica
    @Override
    public Iterator<Card> iterator() {
        return banco.iterator();
    }

    @Override
    public HandRank evaluate(PokerHand pokerHand) {
        return null;
    }

    //Creo in alternativa alla lista un array in cui metto la mano
    //Card[] hand;

    public enum HandRank {
        HIGH_CARD,
        ONE_PAIR,
        TWO_PAIR,
        THREE_OF_A_KIND,
        STRAIGHT,
        FLUSH,
        FULL_HOUSE,
        FOUR_OF_A_KIND,
        STRAIGHT_FLUSH
    }

    //devo passare come parametro anche il mazzo da cui pescare (guardare com'e' stata posta la domanda)
    //non dobbiamo crearlo dentro altrimenti ogni giocatore attingera' a mazzi diversi (problema)
    public PokerHand (int numero_carte, Deck deck ){
        //Deck deck = new Deck();
        //List<Card> banco = new ArrayList<>();
        //se usassimo un'array (che invece e' immutabile) va inizializzato fuori dal costruttore
        // hand = new Card[numero_carte];


        for (int i = 0; i < numero_carte && !deck.isEmpty(); i++) {
            banco.add(deck.draw());
        }
       // System.out.print(banco);
    }

    public PokerHand(int numero_carte, String stringa) {
        banco = List.of(new Card[numero_carte]);
        Scanner input = new Scanner(stringa);
        int i = 0;
        while (input.hasNext()) {
            String card = input.next();
            banco.set(i, Card.get(Card.parseRank(card), Card.parseSuit(card)));
            i++;
        }
    }

    public PokerHand(List<Card> carte) {
        List<Card> copia = new ArrayList<>();
        copia = carte;
    }

    public HandRank getRank() {
        //Proviamo a farlo prima con dei metodi if dal metodo piu' importante a quello meno (schala reale, scala, colore..)
        /*if (hoPoker()) {
            return HandRank.FOUR_OF_A_KIND;
        } else if (hoColore()){
            return HandRank.FLUSH;
        }else if (hoTris()){
            return HandRank.THREE_OF_A_KIND;
        } else if (hoCoppia()) {
            return HandRank.ONE_PAIR;
        } else {
            return HandRank.HIGH_CARD;
        }*/

        // ChainEvaluator Pattern

       //ChainedHandEvaluator evaluator = new hoFlus( new hoTris( new hoHigcard()));
       ChainedHandEvaluator evaluator = new hoFlus( new hoCoppia(new hoHigcard()));

       return evaluator.evaluate(this);
    }

    private boolean hoColore() {
        Card carta = banco.get(0);
        Rank colore = carta.getRank();
        for (Card card :
                banco) {
            if (card.getRank() != colore) {
                return false;
            }
        }
        return true;
    }

    private boolean hoPoker() {
        int cont = 1;

        for (Card card: banco) {
            cont =1;
            for (Card card2: banco) {
                if (card.getRank() == card2.getRank() && card.getSuit() != card2.getSuit()) {
                    cont++;
                }
            }

            if (cont == 4) {
                break;
            }
        }

        //System.out.println(cont);

        if (cont == 4) {
            return true;
        }
        return false;
    }

    /*private boolean hoDoppiaCoppia() {
        int cont = 1;
        this.hoCoppia();
        loop1: for (Card card : banco) {
            loop2: for (Card card2 : banco) {
                if (card.getRank() == card2.getRank() && card.getSuit() != card2.getSuit()) {
                    cont++;
                    continue loop1;
                }
            }

            if (cont == 3){
                break;
            }
        }

        if (cont == 4) {
            return true;
        }
        return false;
    } */

    /* Soluzione che da errore
    * private boolean hoCoppia() {
        int cont = 1;

        for (Card card: banco) {
            cont =1;
            * Rank rank = card.getRank();
            * Suit suit = card.getSuit();
            for (Card card2: banco) {
            *   Rank rank2 = card2.getRank();
            *   Suit suit2 = card2.getSuit();
                if (rank == rank2 && suit != suit2) {
                    cont++;
                }
            }

            if (cont == 2) {
                break;
            }
        }

        System.out.println(cont);

        if (cont == 2) {
            return true;
        }
        return false;
    }*/
    private boolean hoCoppia() {
        int cont = 1;

        for (Card card: banco) {
            cont =1;
            for (Card card2: banco) {
                if (card.getRank() == card2.getRank() && card.getSuit() != card2.getSuit()) {
                    cont++;
                }
            }

            if (cont == 2) {
                break;
            }
        }

        //System.out.println(cont);

        if (cont == 2) {
            return true;
        }
        return false;
    }

    private boolean hoTris() {
        int cont = 1;

        for (Card card: banco) {
            cont =1;
            for (Card card2: banco) {
                if (card.getRank() == card2.getRank() && card.getSuit() != card2.getSuit()) {
                    cont++;
                }
            }

            if (cont == 3) {
                break;
            }
        }

        //System.out.println(cont);

        if (cont == 3) {
            return true;
        }
        return false;
    }






    public static void main(String[] args) {
        int n_carte = 5;
        Deck deck = new Deck();
        PokerHand pokerHand = new PokerHand(n_carte, deck);
        PokerHand B = new PokerHand(n_carte, deck);

        Card card = pokerHand.banco.get(0);
        //pokerHand.banco.get(0)= card.get("ACE");
       // System.out.println(card);
        System.out.println(pokerHand);
        System.out.println(B);

        HandRank risultato1 = pokerHand.getRank();
        HandRank risultato2 = B.getRank();


        System.out.println("Il punteggio della prima mano e':" + risultato1 + "\n" + "Il punteggio della seconda mano e':" + risultato2);
        System.out.println("Il vincitore e':" + risultato1.compareTo(risultato2));

        PokerTable C = new PokerTable(5, deck);
        PokerHand manoProva = PokerTable.getHand(2);
        System.out.println(manoProva);
        System.out.println(C.change(2, manoProva.banco.subList(0,3)));
    }

    @Override
    public String toString() {
        StringBuilder result = new StringBuilder("Le mie carte sono:\n");
        for (Card card : banco) {
            result.append(card.toString());
            result.append("\n");
        }
        //System.out.println(result);
        return result.toString();
    }

}
