package it.unimi.di.prog2.poker;
import ca.mcgill.cs.stg.solitaire.cards.*;

public class hoFlus implements ChainedHandEvaluator {

    private final ChainedHandEvaluator next;

    public hoFlus(ChainedHandEvaluator nextEvaluator) {

        next = nextEvaluator;
    }

    @Override
    public PokerHand.HandRank evaluate(PokerHand pokerHand) {

        Suit suit = null;
        for (Card card : pokerHand) {
            if (suit == null) {
                suit = card.getSuit();
            } else if (suit != card.getSuit()) {
                return next.evaluate(pokerHand);
            }
        }
        return PokerHand.HandRank.FLUSH;
    }

}
