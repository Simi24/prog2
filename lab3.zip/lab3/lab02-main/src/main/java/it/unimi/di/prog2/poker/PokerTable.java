package it.unimi.di.prog2.poker;

import ca.mcgill.cs.stg.solitaire.cards.*;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class PokerTable implements Iterable<PokerHand> {
    private static List<PokerHand> players = new ArrayList<>();
    private Deck deck;

    @Override
    public Iterator<PokerHand> iterator() {
        return players.iterator();
    }

    public PokerTable(int numero_giocatori, Deck deck) {

        this.deck = deck;
        for (int i = 0; i < numero_giocatori; i++) {
            PokerHand giocatore = new PokerHand(5, deck);
            players.add(giocatore);
            //System.out.println(giocatore);
        }

    }

    public static PokerHand getHand(int i){

        PokerHand copia = players.get(i);
        return copia;
    }

    public PokerHand change(int player, List<Card> toChange) {
        System.out.println(toChange);
        List<Card> appoggio = new ArrayList<>();

        PokerHand giocatore = players.get(player);
/*
* il problema nel for e' che continua a ciclare con la prima carta del giocatore sulle carte da cambiare*/

        for (Card card : toChange) {
            for (Card card1 : giocatore) {
                //System.out.println(card);
                //System.out.println(card1);
                if (card == card1) {
                    appoggio.add(deck.draw());
                    continue;
                } else if (card != card1){
                    appoggio.add(card1);
                    continue;
                }
            }
        }

        System.out.println(appoggio);

        PokerHand ritorno = new PokerHand((appoggio));
        players.set(player, ritorno);


        return ritorno;
    }



}
