package it.unimi.di.prog2.poker;

import it.unimi.di.prog2.poker.PokerHand.HandRank;

public interface ChainedHandEvaluator {
     HandRank evaluate(PokerHand pokerHand);


}
