package it.unimi.di.prog2.poker;

import java.util.ArrayList;
import it.unimi.di.prog2.poker.PokerHand.HandRank;

public interface Comparable {


}
