package it.unimi.di.prog2.esame.presenter;

import it.unimi.di.prog2.esame.Main;
import it.unimi.di.prog2.esame.model.Candidato;
import it.unimi.di.prog2.esame.model.Observer;
import it.unimi.di.prog2.esame.model.Subject;
import it.unimi.di.prog2.esame.model.VotaModel;
import it.unimi.di.prog2.esame.view.RisultatiView;
import org.jetbrains.annotations.NotNull;

import java.util.Comparator;
import java.util.List;

public class RisultatiPresenter implements Observer<List<Candidato>> {
    private final RisultatiView view;
    private final VotaModel model;


    public RisultatiPresenter(@NotNull RisultatiView view, VotaModel model) {
        this.view = view;
        this.model = model;
        model.addObserver(this);
    }


    @Override
    public void update(Subject<List<Candidato>> sbj, List<Candidato> state) {
        int numeroVotanti = model.getVotanti();
        view.set(0, "Numero votanti: " + numeroVotanti);
        state.sort(Comparator.comparing(Candidato::getVoti).reversed());
        int posizione = 1;

        if(numeroVotanti >= 3){
            for(Candidato candidato : state){
                view.set(posizione, candidato.toString());
                posizione++;
            }
        }
        view.set(view.size()-1, model.getSchedaBianca().toString());
        while (posizione < Main.MAX_CANDIDATES + 1) {
            view.set(posizione++, "");
        }
    }

}
