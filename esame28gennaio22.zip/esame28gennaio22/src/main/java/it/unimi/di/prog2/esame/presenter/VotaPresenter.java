package it.unimi.di.prog2.esame.presenter;


import it.unimi.di.prog2.esame.Main;
import it.unimi.di.prog2.esame.model.Candidato;
import it.unimi.di.prog2.esame.model.Observer;
import it.unimi.di.prog2.esame.model.Subject;
import it.unimi.di.prog2.esame.model.VotaModel;
import it.unimi.di.prog2.esame.view.VotaView;
import org.jetbrains.annotations.NotNull;

import java.util.Comparator;
import java.util.List;

public class VotaPresenter implements Presenter, Observer<List<Candidato>> {
  private final VotaView view;
  private final VotaModel model;


  public VotaPresenter(@NotNull VotaView view, VotaModel model) {
    this.view = view;
    this.model = model;
    view.addHandlers(this);
    model.addObserver(this);
  }

  @Override
  public final void action(String text1, String text2) {

    System.err.printf("{%s} [%s]\n", text1, text2);
    //Controllo che non venga inserito un codice vuoto
    //Potrei anche controllare che venga inserito un numero e passarlo al modello direttamente come numero e nel caso sollevare un eccezione
    if(text1.length() > 0){
      //Passo al modello il codice identificativo del votante ed il nome del candidato e sara' lui a fare il controllo se puo' votare e aumenta i voti
      boolean possoVotare = model.vota(text1, text2);
      if(possoVotare){
        view.success();
      } else {
        view.fail();
      }
    } else {
      view.fail();
      System.err.println("Non hai inserito il codice");
    }
  }

  @Override
  public void update(Subject<List<Candidato>> sbj, List<Candidato> state) {

    int posizione =0;
    state.sort(Comparator.comparing(Candidato::getNome));

    for(Candidato candidato : state){
      view.set(posizione, candidato.getNome());
      posizione++;
    }

    view.set(Main.MAX_CANDIDATES, model.getSchedaBianca().getNome());

    while (posizione < Main.MAX_CANDIDATES) {
      view.set(posizione++, "");
    }
  }
}
