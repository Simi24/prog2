package it.unimi.di.prog2.esame.presenter;

import it.unimi.di.prog2.esame.model.VotaModel;
import it.unimi.di.prog2.esame.view.CandidaView;
import org.jetbrains.annotations.NotNull;

import java.util.Locale;

public class CandidaPresenter implements Presenter{

    private final CandidaView view;
    private final VotaModel model;

    public CandidaPresenter(@NotNull CandidaView view, VotaModel model) {
        this.view = view;
        this.model = model;
        view.addHandlers(this);
    }

    @Override
    public void action(String text1, String text2) {
        //Alla pressione del tasto candida mi viene passato il nome del candidato (text1) e null
        //Parsare il nome inserito in modo che sia senza spazi e tutto maiuscolo, solo se il nome e' un nome valido
        String candidatoParsato = text1.toUpperCase(Locale.ROOT).trim();
        if(candidatoParsato.matches("[a-zA-Z]+") && candidatoParsato.length() > 1){
            model.candida(candidatoParsato);
            view.success();
        } else{
            System.err.println("Nome del candidato non valido");
            view.fail();
        }


        //Inserire il nome nel modello che fara' i controlli se esiste gia' o se abbiamo gia' raggiunto i 5 candidati

    }
}
