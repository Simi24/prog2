package it.unimi.di.prog2.esame.model;

import it.unimi.di.prog2.esame.Main;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class VotaModel implements Subject<List<Candidato>>{
    private final List<Observer<List<Candidato>>> observers = new ArrayList<>();
    private final List<Candidato> candidati = new ArrayList<>();
    private Candidato schedaBianca = new Candidato("SCHEDA BIANCA", 0);
    private int votanti = 0;

    //per i codici dei candidati creo una lista di interi e quando uno vota rimuovo il suo codice
    //private final List<Integer> codici = new ArrayList<Integer>();

    private final List<Integer> codici = IntStream.rangeClosed(1, 4000)
            .boxed().collect(Collectors.toList());

    public void candida(String candidato) {

        Candidato nuovoCandidato = new Candidato(candidato, 0);

        if(candidati.size() < Main.MAX_CANDIDATES && !presenteCandidato(this.candidati, nuovoCandidato)){
            candidati.add(nuovoCandidato);
        }
        notifyObservers();
    }

    private boolean presenteCandidato(List<Candidato> list, Candidato nuovoCandidato){
        for(Candidato candidato : list){
            if(candidato.equals(nuovoCandidato)){
                return true;
            }
        }

        return false;
    }

    public boolean vota(String text1, String text2) {
        //text1 = codice
        //text2 = nome candidato

        String[] parts = text2.split(":");
        System.err.println("stampa codice " + text1 + "Nome candidato: " + parts[0].trim());
        String nome = parts[0].trim();

        int codice = Integer.parseInt(text1);
        int indice = codici.indexOf(codice);

        if(codici.contains(codice)){
            if((Objects.equals(schedaBianca.getNome(), nome))){
                schedaBianca = schedaBianca.vota();
                codici.remove(indice);
                votanti++;
                notifyObservers();
                return true;
            }
            for(Candidato candidato : candidati){
                if((Objects.equals(candidato.getNome(), nome))){
                    candidati.set(candidati.indexOf(candidato), candidato.vota());
                    codici.remove(indice);
                    votanti++;
                    notifyObservers();
                    return true;
                }
            }
        }
        System.err.println("non entra mai");
        return false;

    }

    @Override
    public void notifyObservers() {
        for(Observer<List<Candidato>> observer : observers){
            observer.update(this, new ArrayList<>(candidati));
        }
    }

    @Override
    public void addObserver(Observer<List<Candidato>> o) {
        observers.add(o);
    }

    @Override
    public List<Candidato> getState() {
        return candidati;
    }

    public Candidato getSchedaBianca() {
        return new Candidato(schedaBianca);
    }

    public int getVotanti() {
        if(votanti < 3){
            return 0;
        }
        return votanti;
    }
}
