package it.unimi.di.prog2.esame.presenter;

public interface Presenter {
  void action(String text1, String text2);
}
