package it.unimi.di.prog2.esame.model;

import org.jetbrains.annotations.NotNull;

import java.util.Objects;

public class Candidato {
    private final String nome;
    private final int voti;

    public Candidato(String nome, int voti) {
        this.nome = nome;
        this.voti = voti;
    }

    public Candidato(Candidato schedaBianca) {
        this.nome = schedaBianca.nome;
        this.voti = schedaBianca.voti;
    }


    public String getNome() {
        return nome;
    }

    public int getVoti() {
        return voti;
    }

    @Override
    public String toString() {
        return nome + " : " + voti;
    }

    @Override
    public boolean equals( @NotNull Object ogg) {
        boolean uguale;
        if (ogg instanceof Candidato) {
            Candidato q = (Candidato) ogg;
            uguale = Objects.equals(nome, q.nome);
        }
        else {
            uguale = false;
        }
        return uguale;
    }


    public Candidato vota() {
        return new Candidato(this.nome, this.voti  + 1);
    }
}
